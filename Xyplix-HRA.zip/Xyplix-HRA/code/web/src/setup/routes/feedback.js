// App Imports
import Interview from '../../modules/feedback/Interview'

// Pages routes
export default {
  feedback: {
    path: '/feedback/:interviewId',
    component: Interview
  }
}
