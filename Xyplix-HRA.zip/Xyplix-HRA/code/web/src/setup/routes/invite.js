// App Imports
import Accept from '../../modules/invite/Accept'

// Pages routes
export default {
  invite: {
    path: '/invite/:code',
    component: Accept
  },
}
