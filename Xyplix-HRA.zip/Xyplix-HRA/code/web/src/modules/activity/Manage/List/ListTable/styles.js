// Component Styles
const styles = {
  textCenter: {
    textAlign: 'center'
  },

  textNoWrap: {
    whiteSpace: 'nowrap'
  }
}

export default styles
