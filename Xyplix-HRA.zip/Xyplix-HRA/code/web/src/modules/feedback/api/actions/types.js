// Actions Types

// List
export const LIST_REQUEST = 'INVITE/LIST/REQUEST'
export const LIST_RESPONSE = 'INVITE/LIST/RESPONSE'
export const LIST_DONE = 'INVITE/LIST/DONE'
export const LIST_RESET = 'INVITE/LIST/RESET'
