// Component Styles
const styles = {
  root: {
    marginTop: '59px !important'
  },

  main: {
    minHeight: 'calc(100vh - 100px)'
  }
}

export default styles
