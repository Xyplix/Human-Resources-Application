// Component Styles
const styles = theme => ({
  textCenter: {
    textAlign: 'center'
  }
})

export default styles
