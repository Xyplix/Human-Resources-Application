// Component Styles
const styles = theme => ({
  column: {
    display: 'inline-block',
    float: 'left',
    height: 'calc(100vh - 202px)',
    overflowY: 'hidden'
  }
})

export default styles
