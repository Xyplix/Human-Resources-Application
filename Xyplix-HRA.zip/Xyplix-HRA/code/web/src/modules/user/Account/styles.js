// UI Imports

// Component Styles
const styles = theme => ({
  root: {
    minHeight: 'calc(100vh - 100px)',
    display: 'flex'
  }
})

export default styles
