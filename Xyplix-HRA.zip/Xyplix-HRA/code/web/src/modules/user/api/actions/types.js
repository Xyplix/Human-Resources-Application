// Actions Types

export const LOGIN_REQUEST = 'AUTH/LOGIN_REQUEST'
export const LOGIN_RESPONSE = 'AUTH/LOGIN_RESPONSE'

export const SET_USER = 'AUTH/SET_USER'

export const LOGOUT = 'AUTH/LOGOUT'
