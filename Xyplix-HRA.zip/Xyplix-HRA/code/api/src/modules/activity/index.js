// App Imports
import * as query from './query'

export default {
  ...query
}
