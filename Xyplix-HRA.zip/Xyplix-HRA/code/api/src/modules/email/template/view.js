const view = (html) => html

export default view
