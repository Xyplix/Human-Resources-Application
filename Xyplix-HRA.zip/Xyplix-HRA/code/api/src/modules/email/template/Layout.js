// Imports
import React from 'react'

// UI Imports

// App Imports

// Component
const Layout = (props) => (
  <div>
    { props.children }
  </div>
)

export default Layout

